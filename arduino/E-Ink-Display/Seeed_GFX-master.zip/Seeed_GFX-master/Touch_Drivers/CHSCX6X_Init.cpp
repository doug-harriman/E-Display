
TOUCH_WIRE.begin();

#ifdef TOUCH_INT
pinMode(TOUCH_INT, INPUT_PULLUP);
#endif